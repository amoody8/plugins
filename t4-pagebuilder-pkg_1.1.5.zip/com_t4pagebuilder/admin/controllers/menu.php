<?php 
/** 
 *------------------------------------------------------------------------------
 * @package       T4 Page Builder for Joomla!
 *------------------------------------------------------------------------------
 * @copyright     Copyright (C) 2004-2020 JoomlArt.com. All Rights Reserved.
 * @license       GNU General Public License version 2 or later; see LICENSE.txt
 * @authors       JoomlArt, JoomlaBamboo, (contribute to this project at github 
 *                & Google group to become co-author)
 *------------------------------------------------------------------------------
 */


defined('_JEXEC') or die;
/**
 * Articles list controller class.
 *
 * @since  1.6
 */
class T4pagebuilderControllerMenu extends JControllerForm
{
	 public function __construct($config = array())
	{
		parent::__construct($config);
	}

}
?>