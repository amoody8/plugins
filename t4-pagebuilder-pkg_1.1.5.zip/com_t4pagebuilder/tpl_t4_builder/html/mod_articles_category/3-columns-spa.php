<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_category
 *
 * @copyright   Copyright (C) 2005 - 2020 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

?>
<div class="blog-list<?php echo $moduleclass_sfx; ?> mod-list spa-style">
	<div class="t4b-jcontent-slide owl-carousel owl-theme">
		<?php foreach ($list as $item) : ?>
			<div class="t4b-jcontent-item text-center">
	      <!-- Item image -->
	      <?php
	      $images = "";
	      if (isset($item->images)) {
	        $images = json_decode($item->images);
	      }

	      $imgexists = (isset($images->image_intro) and !empty($images->image_intro)) || (isset($images->image_fulltext) and !empty($images->image_fulltext));

	      if ($imgexists) {
	      	$images->image_intro = $images->image_intro?$images->image_intro:$images->image_fulltext;
	      ?>

	      <a class="item-image" href="<?php echo $item->link; ?>">
	        <img src="<?php echo htmlspecialchars($images->image_intro); ?>" alt="<?php echo $item->title; ?>" />
	      </a>
	      <?php } ?>
	      <!-- // Item image -->

				<div class="article-meta">
					<?php if ($item->displayCategoryTitle) : ?>
						<span class="mod-articles-category-category">
							<?php echo $item->displayCategoryTitle; ?>
						</span>
					<?php endif; ?>

					<?php if ($item->displayDate) : ?>
						<span class="item-date">
							<?php echo $item->displayDate; ?>
						</span>
					<?php endif; ?>

					<?php if ($params->get('show_author')) : ?>
						<span class="mod-articles-category-writtenby">
							<?php echo $item->displayAuthorName; ?>
						</span>
					<?php endif; ?>
				</div>

				<?php if ($params->get('link_titles') == 1) : ?>
					<h3 class="item-title"><a class="mod-articles-category-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>"><?php echo $item->title; ?></a></h3>
				<?php else : ?>
					<h3><?php echo $item->title; ?></h3>
				<?php endif; ?>

				<?php if ($params->get('show_tags', 0) && $item->tags->itemTags) : ?>
					<div class="mod-articles-category-tags">
						<?php echo JLayoutHelper::render('joomla.content.tags', $item->tags->itemTags); ?>
					</div>
				<?php endif; ?>

				<?php if ($params->get('show_introtext')) : ?>
					<p class="item-introtext">
						<?php echo $item->displayIntrotext; ?>
					</p>
				<?php endif; ?>

				<?php if ($item->displayHits) : ?>
					<span class="mod-articles-category-hits">
						Hits: <?php echo $item->displayHits; ?>
					</span>
				<?php endif; ?>

				<?php if ($params->get('show_readmore')) : ?>
					<p class="item-readmore">
						<a class="mod-articles-category-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
							<?php if ($item->params->get('access-view') == false) : ?>
								<?php echo JText::_('MOD_ARTICLES_CATEGORY_REGISTER_TO_READ_MORE'); ?>
							<?php elseif ($readmore = $item->alternative_readmore) : ?>
								<?php echo $readmore; ?>
								<?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
							<?php elseif ($params->get('show_readmore_title', 0) == 0) : ?>
								<?php echo JText::sprintf('MOD_ARTICLES_CATEGORY_READ_MORE_TITLE'); ?>
							<?php else : ?>
								<?php echo JText::_('MOD_ARTICLES_CATEGORY_READ_MORE'); ?>
								<?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
							<?php endif; ?>
						</a>
					</p>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

<script>
	jQuery(document).ready(function($) {
		jQuery('.t4b-jc__flat-9 .owl-carousel').owlCarousel({
	    autoHeight: true,
	    margin: 30,
	    nav: false,
	    responsive:{
	      0:{
	        items:1,
	      },
	      768:{
	        items:2
	      },
	      992:{
	        items:3,
	      },
	      1728:{
	        margin: 38,
	      }
	    }
	  })
	})
</script>