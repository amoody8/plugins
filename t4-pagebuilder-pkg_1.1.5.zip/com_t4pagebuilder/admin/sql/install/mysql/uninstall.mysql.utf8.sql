DROP TABLE IF EXISTS `#__jae_item`;
DROP TABLE IF EXISTS `#__jae_revision`;
